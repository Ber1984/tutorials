# docker exec -it postgres psql -U amigoscode

- psql -U <The name of the user>  psql -U amigoscode to connect to postgres
- \c <name of the database>  \c to change database
- \d <Table> see the table for example \d customer
- \l to see all the database in postgress