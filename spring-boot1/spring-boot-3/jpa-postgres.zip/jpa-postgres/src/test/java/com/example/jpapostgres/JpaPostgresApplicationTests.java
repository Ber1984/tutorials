package com.example.jpapostgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaPostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
